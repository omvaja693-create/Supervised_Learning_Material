from pathlib import Path
import json, pickle, pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, VotingClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR/'data/loan_approval.csv'

MODEL_DIR = BASE_DIR/'model'
MODEL_DIR.mkdir(exist_ok = True)

NUM = ['age', 'income', 'loan_amount', 'credit_score', 'employment_years', 'existing_loans', 'dependents']
CAT = ['education', 'self_employed', 'property_area']
TARGET = 'loan_approved'

df = pd.read_csv(DATA_PATH)

X = df[NUM+CAT]
y = df[TARGET]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.20, random_state = 42, stratify = y)

num_pipe = Pipeline([
    ('imputer', SimpleImputer(strategy = 'median')), 
    ('scaler', StandardScaler())
    ])
cat_pipe = Pipeline([
    ('imputer', SimpleImputer(strategy = 'most_frequent')), 
    ('encoder', OneHotEncoder(handle_unknown = 'ignore'))
    ])
pre = ColumnTransformer([
    ('numeric', num_pipe, NUM), 
    ('categorical', cat_pipe, CAT)
    ])
ens = VotingClassifier(
    estimators = [
        ('logistic', LogisticRegression(max_iter = 1000, random_state = 42)), 
        ('random_forest', RandomForestClassifier(n_estimators = 250, max_depth = 8, random_state = 42, n_jobs = -1)), 
        ('adaboost', AdaBoostClassifier(n_estimators = 150, learning_rate = .05, random_state = 42))
        ], 
        voting = 'soft', 
        weights = [1, 2, 2]
    )
pipeline = Pipeline([('preprocessing', pre), ('ensemble', ens)])

pipeline.fit(X_train, y_train)
yp = pipeline.predict(X_test)
pr = pipeline.predict_proba(X_test)[:, 1]
cm = confusion_matrix(y_test, yp)

metrics = {
    'accuracy':float(accuracy_score(y_test, yp)), 
    'precision':float(precision_score(y_test, yp, zero_division = 0)), 
    'recall':float(recall_score(y_test, yp, zero_division = 0)), 
    'f1_score':float(f1_score(y_test, yp, zero_division = 0)), 
    'roc_auc':float(roc_auc_score(y_test, pr)), 
    'confusion_matrix':cm.tolist(), 
    'train_rows':len(X_train), 
    'test_rows':len(X_test), 
    'ensemble':'Soft Voting Classifier', 
    'base_models':['Logistic Regression', 'Random Forest', 'AdaBoost']
    }

with open(MODEL_DIR/'loan_approval_ensemble_pipeline.pkl', 'wb') as f:
    pickle.dump(pipeline, f)

(MODEL_DIR/'metrics.json').write_text(json.dumps(metrics, indent = 4))

print(json.dumps(metrics, indent = 4))
