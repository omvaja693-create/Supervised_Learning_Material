# Deployment Checklist

- Install requirements
- Run `python train_model.py`
- Run `streamlit run app.py`
- Push `app.py`, `requirements.txt`, `model/*.pkl`, `model/metrics.json`, and `data/loan_approval.csv` to GitHub
- Deploy `app.py` on Streamlit Community Cloud
- Never commit secrets
