from pathlib import Path
import json, pickle, pandas as pd, streamlit as st

B = Path(__file__).resolve().parent

@st.cache_resource
def load(): 
  return pickle.load(open(B/'model/loan_approval_ensemble_pipeline.pkl', 'rb'))

@st.cache_data
def metrics(): 
  return json.loads((B/'model/metrics.json').read_text())

model = load()
m = metrics()
st.set_page_config(page_title = 'Ensemble Loan Approval', page_icon = '🏦')
st.title('🏦 Loan Approval Prediction')
st.caption('Soft Voting Ensemble • Pipeline • Pickle • Streamlit')

with st.form('loan'):
 c1, c2 = st.columns(2)
 
 with c1:
  age = st.number_input('Age', 18, 100, 30)
  income = st.number_input('Monthly Income (₹)', 5000., 1000000., 75000., 5000.)
  loan_amount = st.number_input('Loan Amount (₹)', 10000., 10000000., 350000., 10000.)
  credit_score = st.number_input('Credit Score', 300, 900, 700)
 
 with c2:
  employment_years = st.number_input('Employment Years', 0, 60, 5)
  existing_loans = st.number_input('Existing Loans', 0, 15, 1)
  dependents = st.number_input('Dependents', 0, 10, 1)
  education = st.selectbox('Education', ['Graduate', 'Not Graduate'])
  self_employed = st.selectbox('Self Employed', ['No', 'Yes'])
  property_area = st.selectbox('Property Area', ['Urban', 'Semiurban', 'Rural'])
 
 submit = st.form_submit_button('🔮 Predict Loan Approval', use_container_width = True)

if submit:
 x = pd.DataFrame({
  'age':[age], 
  'income':[income], 
  'loan_amount':[loan_amount], 
  'credit_score':[credit_score], 
  'employment_years':[employment_years], 
  'existing_loans':[existing_loans], 
  'dependents':[dependents], 
  'education':[education], 
  'self_employed':[self_employed], 
  'property_area':[property_area]
  })
 
 p = float(model.predict_proba(x)[0, 1])
 pred = int(model.predict(x)[0])
 
 st.divider()

 if pred:
   st.success("✅ Prediction: LOAN LIKELY TO BE APPROVED")
 else:
   st.error("❌ Prediction: LOAN LIKELY TO BE REJECTED")
 
 st.metric('Approval Probability', f'{p:.1%}')
 st.progress(p)
 st.dataframe(x, use_container_width = True)

with st.expander('📊 Model Evaluation'):
 a, b, c, d = st.columns(4)
 a.metric('Accuracy', f"{m['accuracy']:.1%}")
 b.metric('Precision', f"{m['precision']:.1%}")
 c.metric('Recall', f"{m['recall']:.1%}")
 d.metric('F1', f"{m['f1_score']:.1%}")
 st.write(f"ROC-AUC: **{m['roc_auc']:.3f}**")

 st.dataframe(pd.DataFrame(
  m['confusion_matrix'], 
  index = ['Actual Rejected', 'Actual Approved'], 
  columns = ['Predicted Rejected', 'Predicted Approved']
  ))
