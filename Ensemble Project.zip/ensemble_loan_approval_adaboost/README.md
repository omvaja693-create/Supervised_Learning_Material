# 🤖 Ensemble Loan Approval — Streamlit Deployment

Ready-to-run educational Ensemble Learning project using a Soft Voting Classifier with Logistic Regression, Random Forest and AdaBoost.

## Run
```bash
pip install -r requirements.txt
python train_model.py
streamlit run app.py
```

## Pipeline
Input → numerical imputation/scaling + categorical imputation/encoding → Soft Voting Ensemble → prediction. The entire pipeline is exported as `model/loan_approval_ensemble_pipeline.pkl`.

The included dataset is synthetic and for educational purposes only.
