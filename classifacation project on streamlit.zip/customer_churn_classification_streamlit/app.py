from pathlib import Path
import json, pickle
import pandas as pd
import streamlit as st

BASE = Path(__file__).resolve().parent

@st.cache_resource
def load_model():
 with open(BASE/'model/customer_churn_pipeline.pkl', 'rb') as f: 
  return pickle.load(f)

@st.cache_data
def load_metrics():
 p = BASE/'model/metrics.json'
 return json.loads(p.read_text()) if p.exists() else {}

model = load_model()
metrics = load_metrics()

st.set_page_config(page_title = 'Customer Churn Predictor', page_icon = '📉', layout = 'centered')
st.title('📉 Customer Churn Prediction')
st.caption('Classification + Pipeline + Pickle + Streamlit')

with st.form('churn_form'):
 c1, c2 = st.columns(2)

 with c1:
  age = st.number_input('Age', 18, 100, 30)
  tenure = st.number_input('Tenure (months)', 1, 120, 12)
  monthly = st.number_input('Monthly Charges (₹)', 0.0, 1000.0, 70.0)
  calls = st.number_input('Support Calls', 0, 30, 2)

 with c2:
  contract = st.selectbox('Contract', ['Month-to-month', 'One year', 'Two year'])
  internet = st.selectbox('Internet Service', ['DSL', 'Fiber optic', 'No'])
  payment = st.selectbox('Payment Method', ['Electronic check', 'Credit card', 'Bank transfer', 'Mailed check'])

 submitted = st.form_submit_button('🔮 Predict Churn', use_container_width = True)

if submitted:
 data = pd.DataFrame({
    'age':[age], 
    'tenure':[tenure], 
    'monthly_charges':[monthly], 
    'support_calls':[calls], 
    'contract':[contract], 
    'internet_service':[internet], 
    'payment_method':[payment]
  })

 pred = int(model.predict(data)[0])
 pr = float(model.predict_proba(data)[0, 1])

 if pred: 
  st.error('⚠️ Prediction: CUSTOMER LIKELY TO CHURN')
 else: 
  st.success('✅ Prediction: CUSTOMER LIKELY TO STAY')

 st.metric('Churn Probability', f'{pr:.1%}')
 st.progress(pr)

 with st.expander('View input data'): 
  st.dataframe(data, use_container_width = True)

st.divider()

with st.expander('📊 Model Evaluation'):
 if metrics:
  a, b, c, d = st.columns(4)

  a.metric('Accuracy', f"{metrics['accuracy']:.1%}")
  b.metric('Precision', f"{metrics['precision']:.1%}")
  c.metric('Recall', f"{metrics['recall']:.1%}")
  d.metric('F1', f"{metrics['f1_score']:.1%}")

  st.write(f"**ROC-AUC:** {metrics['roc_auc']:.3f}")
  st.dataframe(pd.DataFrame(
      metrics['confusion_matrix'], 
      index = ['Actual Stay', 'Actual Churn'], 
      columns = ['Predicted Stay', 'Predicted Churn']
    ))