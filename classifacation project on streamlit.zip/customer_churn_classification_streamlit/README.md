# 📉 Customer Churn Classification — Streamlit Deployment

Complete ML classification project using mixed numeric/categorical preprocessing, Logistic Regression, pickle serialization and Streamlit.

## Run
```bash
pip install -r requirements.txt
python train_model.py
streamlit run app.py
```

## Pipeline
Numerical: SimpleImputer → StandardScaler

Categorical: SimpleImputer → OneHotEncoder(handle_unknown="ignore")

Then: LogisticRegression

The entire pipeline is exported as `model/customer_churn_pipeline.pkl`.

## Deployment
Push `app.py`, `requirements.txt`, `model/customer_churn_pipeline.pkl`, `model/metrics.json`, and `data/customer_churn.csv` to GitHub, then deploy `app.py` on Streamlit Community Cloud.

The dataset is synthetic and for educational use only.
