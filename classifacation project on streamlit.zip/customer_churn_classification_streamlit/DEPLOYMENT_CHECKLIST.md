# Deployment Checklist

- [ ] Install requirements
- [ ] Run `python train_model.py`
- [ ] Confirm `.pkl` exists
- [ ] Run `streamlit run app.py`
- [ ] Test Stay and Churn cases
- [ ] Push project to GitHub
- [ ] Deploy `app.py` on Streamlit Community Cloud
- [ ] Never commit secrets/API keys
