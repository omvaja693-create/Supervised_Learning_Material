from pathlib import Path
import json,  pickle
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score,  precision_score,  recall_score,  f1_score,  roc_auc_score,  confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder,  StandardScaler

BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR/'data/customer_churn.csv'

MODEL_DIR = BASE_DIR/'model'
MODEL_DIR.mkdir(exist_ok = True)

NUM = ['age', 'tenure', 'monthly_charges', 'support_calls']
CAT = ['contract', 'internet_service', 'payment_method']
TARGET = 'churn'

df = pd.read_csv(DATA_PATH)

X = df[NUM+CAT]
y = df[TARGET]

X_train,  X_test,  y_train,  y_test = train_test_split(X, y, test_size=0.20, random_state=42, stratify=y)

num_pipe = Pipeline([
        ('imputer', SimpleImputer(strategy='median')), 
        ('scaler', StandardScaler())
    ])
cat_pipe = Pipeline([
        ('imputer', SimpleImputer(strategy='most_frequent')), 
        ('encoder', OneHotEncoder(handle_unknown='ignore'))
    ])
pre = ColumnTransformer([
        ('numeric', num_pipe, NUM), 
        ('categorical', cat_pipe, CAT)
    ])
pipeline = Pipeline([
        ('preprocessing', pre), 
        ('model', LogisticRegression(max_iter=1000))
    ])

pipeline.fit(X_train, y_train)

pred = pipeline.predict(X_test)
p = pipeline.predict_proba(X_test)[:, 1]
cm = confusion_matrix(y_test, pred)

metrics = {
        'accuracy':float(accuracy_score(y_test, pred)), 
        'precision':float(precision_score(y_test, pred, zero_division=0)), 
        'recall':float(recall_score(y_test, pred, zero_division=0)), 
        'f1_score':float(f1_score(y_test, pred, zero_division=0)), 
        'roc_auc':float(roc_auc_score(y_test, p)), 
        'confusion_matrix':cm.tolist(), 
        'train_rows':len(X_train), 
        'test_rows':len(X_test), 
        'numeric_features':NUM, 
        'categorical_features':CAT, 
        'target':TARGET
    }

with open(MODEL_DIR/'customer_churn_pipeline.pkl', 'wb') as f: 
    pickle.dump(pipeline, f)

(MODEL_DIR/'metrics.json').write_text(json.dumps(metrics, indent=4))

print(json.dumps(metrics, indent=2))
